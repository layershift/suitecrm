<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version = '7.11.5';
$suitecrm_timestamp = '2019-06-03 17:00:00';
